var printApp = angular.module('printApp');

//This will create a controller which will be used in our app
printApp.controller('printController', function ($scope, getService) {

    $scope.Log = [];

    getService.getData('/admin/students/RSPE/scripts/logCat.json').then(function (retData) {
        retData.pop();
        $scope.Log = retData;

        $scope.data = [];

        getService.getData('/admin/students/RSPE/scripts/student_RSPE.json?DCID=' + $j('#DCID').html() + '&ID=' + $j('#ID').html()).then(function (retData) {
            retData.pop();
            $scope.data = retData;

        });
    });
 
}); //Close controller

printApp.factory('getService', function ($http) {
    return {
        getData: function (dataFile) {
            //Return promise directly
            return $http.get(dataFile).then(function (result) {
                return result.data;
            });
        }
    };
}); //Close Factory

printApp.filter('ampersand', function () {
    return function (input) {
        return input ? input.replace(/&amp;/, '&') : '';
    }
});

